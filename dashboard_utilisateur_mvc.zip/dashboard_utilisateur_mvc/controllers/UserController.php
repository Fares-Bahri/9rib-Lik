<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';

class UserController
{
    public const PER_PAGE = 10;

    private const SORTS = [
        'id' => 'id', 'nom' => 'nom', 'prenom' => 'prenom',
        'email' => 'email', 'role' => 'role', 'date' => 'date_creation',
    ];
    private const ROLES = ['user', 'admin'];

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnexion();
    }

    private function buildWhere(string $q, string $role): array
    {
        $where = [];
        $params = [];
        if ($q !== '') {
            $where[] = '(nom LIKE :q1 OR prenom LIKE :q2 OR email LIKE :q3)';
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $params['q1'] = $params['q2'] = $params['q3'] = $like;
        }
        if (in_array($role, self::ROLES, true)) {
            $where[] = 'role = :role';
            $params['role'] = $role;
        }
        return [$where ? ' WHERE ' . implode(' AND ', $where) : '', $params];
    }

    public function findAll(string $q = '', string $role = '', string $sort = 'id', string $dir = 'asc', int $page = 1): array
    {
        [$where, $params] = $this->buildWhere($q, $role);
        $col = self::SORTS[$sort] ?? 'id';
        $direction = strtolower($dir) === 'desc' ? 'DESC' : 'ASC';
        $offset = max(0, ($page - 1) * self::PER_PAGE);

        $stmt = $this->db->prepare(
            "SELECT * FROM utilisateur$where ORDER BY $col $direction, id ASC LIMIT :limit OFFSET :offset"
        );
        foreach ($params as $k => $v) {
            $stmt->bindValue(':' . $k, $v);
        }
        $stmt->bindValue(':limit', self::PER_PAGE, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return array_map([UserModel::class, 'fromArray'], $stmt->fetchAll());
    }

    public function countFiltered(string $q = '', string $role = ''): int
    {
        [$where, $params] = $this->buildWhere($q, $role);
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM utilisateur$where");
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    public function pageCount(int $total): int
    {
        return max(1, (int) ceil($total / self::PER_PAGE));
    }

    public function countAll(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM utilisateur')->fetchColumn();
    }

    public function countByRole(string $role): int
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM utilisateur WHERE role = :role');
        $stmt->execute(['role' => $role]);
        return (int) $stmt->fetchColumn();
    }

    public function countNewThisMonth(): int
    {
        return (int) $this->db->query(
            "SELECT COUNT(*) FROM utilisateur WHERE date_creation >= DATE_FORMAT(CURDATE(), '%Y-%m-01')"
        )->fetchColumn();
    }

    public function delete(int $id, int $currentUserId): ?string
    {
        if ($id <= 0) {
            return 'Utilisateur introuvable.';
        }
        if ($id === $currentUserId) {
            return 'Vous ne pouvez pas supprimer votre propre compte.';
        }
        $stmt = $this->db->prepare('SELECT email FROM utilisateur WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $email = $stmt->fetchColumn();
        if ($email === false) {
            return 'Utilisateur introuvable.';
        }
        $this->db->beginTransaction();
        try {
            $this->db->prepare('DELETE FROM password_resets WHERE email = :email')->execute(['email' => $email]);
            $this->db->prepare('DELETE FROM utilisateur WHERE id = :id')->execute(['id' => $id]);
            $this->db->commit();
        } catch (Throwable $e) {
            $this->db->rollBack();
            return 'Erreur lors de la suppression.';
        }
        return null;
    }
}
