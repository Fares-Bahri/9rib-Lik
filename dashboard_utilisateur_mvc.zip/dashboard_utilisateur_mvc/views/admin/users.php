<?php
/**
 * views/admin/users.php
 * Attend : $users (UserModel[]), $q, $role, $sort, $dir, $page, $pages, $total,
 *          $totalUsers, $totalAdmins, $totalNouveaux, $user (utilisateur connecté)
 */
ob_start();
$extraCss = 'assets/css/users.css';

// URL de la page en conservant recherche, filtre, tri et page
$url = function (array $over = []) use ($q, $role, $sort, $dir, $page): string {
    $p = array_merge(['action' => 'admin_users', 'q' => $q, 'role' => $role, 'sort' => $sort, 'dir' => $dir, 'page' => $page], $over);
    foreach (['q', 'role'] as $k) { if ($p[$k] === '') unset($p[$k]); }
    if ($p['sort'] === 'id' && $p['dir'] === 'asc') { unset($p['sort'], $p['dir']); }
    if ((int) $p['page'] <= 1) { unset($p['page']); }
    return 'index.php?' . http_build_query($p);
};
// En-tête de colonne cliquable (tri)
$th = function (string $key, string $label) use ($sort, $dir, $url): string {
    $active = ($sort === $key);
    $next = ($active && $dir === 'asc') ? 'desc' : 'asc';
    $aria = $active ? ($dir === 'asc' ? 'ascending' : 'descending') : 'none';
    $arrow = $active ? ($dir === 'asc' ? '↑' : '↓') : '↕';
    return '<th aria-sort="' . $aria . '"><a href="' . e($url(['sort' => $key, 'dir' => $next, 'page' => 1])) . '">'
         . e($label) . ' <span class="fl">' . $arrow . '</span></a></th>';
};
?>
<div class="stats">
  <div class="stat"><span>Utilisateurs</span><b><?= (int) $totalUsers ?></b></div>
  <div class="stat"><span>Administrateurs</span><b><?= (int) $totalAdmins ?></b></div>
  <div class="stat"><span>Nouveaux ce mois-ci</span><b><?= (int) $totalNouveaux ?></b></div>
</div>

<div class="card">
  <div class="bar">
    <form class="filtre" method="get" action="index.php">
      <input type="hidden" name="action" value="admin_users">
      <input type="hidden" name="sort" value="<?= e($sort) ?>">
      <input type="hidden" name="dir" value="<?= e($dir) ?>">
      <input type="search" name="q" value="<?= e($q) ?>" placeholder="Rechercher un utilisateur..." aria-label="Rechercher">
      <select name="role" aria-label="Filtrer par rôle">
        <option value="">Tous les rôles</option>
        <option value="user"<?= $role === 'user' ? ' selected' : '' ?>>Utilisateur</option>
        <option value="admin"<?= $role === 'admin' ? ' selected' : '' ?>>Administrateur</option>
      </select>
      <button class="btn sec" type="submit">Rechercher</button>
      <?php if ($q !== '' || $role !== ''): ?><a class="btn sec" href="index.php?action=admin_users">Réinitialiser</a><?php endif; ?>
    </form>
    <a class="btn" href="index.php?action=admin_user_form">Ajouter un utilisateur</a>
  </div>

  <table class="users">
    <thead>
      <tr>
        <?= $th('id', 'ID') ?><?= $th('nom', 'Nom') ?><?= $th('prenom', 'Prénom') ?>
        <?= $th('email', 'Email') ?><?= $th('role', 'Rôle') ?><?= $th('date', 'Date de création') ?>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= $u->getId() ?></td>
        <td><?= e($u->getNom()) ?></td>
        <td><?= e($u->getPrenom()) ?></td>
        <td><?= e($u->getEmail()) ?></td>
        <td>
          <?php if ($u->getRole() === 'admin'): ?><span class="badge warn">Administrateur</span>
          <?php else: ?><span class="badge">Utilisateur</span><?php endif; ?>
        </td>
        <td><?= e(date('d/m/Y', strtotime($u->getDateCreation()))) ?></td>
        <td class="actions">
          <a class="btn sm sec" href="index.php?action=admin_user&amp;id=<?= $u->getId() ?>">Voir</a>
          <a class="btn sm sec" href="index.php?action=admin_user_form&amp;id=<?= $u->getId() ?>">Modifier</a>
          <form class="inline" method="post" action="index.php?action=admin_user_delete" data-confirm="Supprimer cet utilisateur ?">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= $u->getId() ?>">
            <button class="btn sm del" type="submit"<?= ($user && $u->getId() === $user->getId()) ? ' disabled title="Vous ne pouvez pas supprimer votre propre compte"' : '' ?>>Supprimer</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (empty($users)): ?><tr><td colspan="7">Aucun utilisateur.</td></tr><?php endif; ?>
    </tbody>
  </table>

  <div class="pied">
    <span class="compte"><?= (int) $total ?> résultat<?= $total > 1 ? 's' : '' ?></span>
    <?php if ($pages > 1): ?>
    <nav class="pagination" aria-label="Pagination">
      <?php if ($page > 1): ?><a href="<?= e($url(['page' => $page - 1])) ?>">‹ Précédent</a><?php endif; ?>
      <?php for ($i = max(1, $page - 2); $i <= min($pages, $page + 2); $i++): ?>
        <?php if ($i === $page): ?><span class="cur" aria-current="page"><?= $i ?></span>
        <?php else: ?><a href="<?= e($url(['page' => $i])) ?>"><?= $i ?></a><?php endif; ?>
      <?php endfor; ?>
      <?php if ($page < $pages): ?><a href="<?= e($url(['page' => $page + 1])) ?>">Suivant ›</a><?php endif; ?>
    </nav>
    <?php endif; ?>
  </div>
</div>
<?php
$content = ob_get_clean();
$title = 'Gestion des utilisateurs';
$activePage = 'utilisateurs';
require __DIR__ . '/../layout_admin.php';
