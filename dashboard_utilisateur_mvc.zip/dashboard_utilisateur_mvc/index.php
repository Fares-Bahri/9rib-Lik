<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
session_start();

$sessionLifetime = 1800;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $sessionLifetime)) {
    $_SESSION = [];
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'");

require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/UserController.php';

$authController = new AuthController();
$userController = new UserController();

function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(AuthController::getCsrfToken()) . '">'; }
function redirect(string $action): void { header('Location: index.php?action=' . $action); exit; }
function flash(?string $msg = null): ?string
{
    if ($msg !== null) { $_SESSION['flash'] = $msg; return null; }
    $m = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $m;
}
function flash_error(?string $msg = null): ?string
{
    if ($msg !== null) { $_SESSION['flash_error'] = $msg; return null; }
    $m = $_SESSION['flash_error'] ?? null;
    unset($_SESSION['flash_error']);
    return $m;
}
function isPost(): bool { return $_SERVER['REQUEST_METHOD'] === 'POST'; }

$action = $_GET['action'] ?? 'home';

switch ($action) {

    case 'home':
        redirect(AuthController::isAuthenticated() ? 'admin_users' : 'login');

    case 'login':
        if (AuthController::isAuthenticated()) { redirect('home'); }
        $errors = [];
        if (isPost()) {
            $errors = $authController->login($_POST);
            if (empty($errors)) { redirect('home'); }
        }
        require __DIR__ . '/views/login.php';
        break;

    case 'logout':
        $authController->logout();
        redirect('login');

    case 'admin_users':
        AuthController::requireRole('admin');
        $user = $authController->findById((int) $_SESSION['user_id']);

        $q    = trim((string) ($_GET['q'] ?? ''));
        $role = (string) ($_GET['role'] ?? '');
        $sort = (string) ($_GET['sort'] ?? 'id');
        $dir  = (($_GET['dir'] ?? 'asc') === 'desc') ? 'desc' : 'asc';

        $total = $userController->countFiltered($q, $role);
        $pages = $userController->pageCount($total);
        $page  = min(max(1, (int) ($_GET['page'] ?? 1)), $pages);
        $users = $userController->findAll($q, $role, $sort, $dir, $page);

        $totalUsers    = $userController->countAll();
        $totalAdmins   = $userController->countByRole('admin');
        $totalNouveaux = $userController->countNewThisMonth();
        require __DIR__ . '/views/admin/users.php';
        break;

    case 'admin_user_delete':
        AuthController::requireRole('admin');
        if (isPost() && AuthController::verifyCsrfToken($_POST['csrf_token'] ?? null)) {
            $error = $userController->delete((int) ($_POST['id'] ?? 0), (int) $_SESSION['user_id']);
            if ($error === null) { flash('Utilisateur supprimé.'); } else { flash_error($error); }
        }
        redirect('admin_users');

    default:
        http_response_code(404);
        echo '404 - Page not found';
        break;
}
