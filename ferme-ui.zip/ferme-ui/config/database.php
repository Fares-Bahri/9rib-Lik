<?php

class Database
{
    private const HOST = 'localhost';
    private const DBNAME = 'gestion_projet';
    private const USERNAME = 'root';
    private const PASSWORD = '';

    private static ?PDO $connexion = null;

    public static function getConnexion(): PDO
    {
        if (self::$connexion === null) {
            try {
                self::$connexion = new PDO(
                    'mysql:host=' . self::HOST . ';dbname=' . self::DBNAME . ';charset=utf8mb4',
                    self::USERNAME,
                    self::PASSWORD
                );
                self::$connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$connexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                die('Erreur de connexion à la base de données : ' . $e->getMessage());
            }
        }
        return self::$connexion;
    }
}

// Compatibilité avec les scripts existants qui utilisent $pdo (ex. create_test_user.php)
$pdo = Database::getConnexion();
