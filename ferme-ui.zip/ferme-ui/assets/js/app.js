// Confirmation avant suppression (compatible avec la CSP : pas de JS inline)
document.querySelectorAll('form[data-confirm]').forEach(function (form) {
  form.addEventListener('submit', function (ev) {
    if (!window.confirm(form.dataset.confirm)) { ev.preventDefault(); }
  });
});

// Envoi automatique du formulaire de photo dès qu'un fichier est choisi
document.querySelectorAll('input[type=file][data-autosubmit]').forEach(function (input) {
  input.addEventListener('change', function () {
    if (!input.files || !input.files.length) return;
    var fichier = input.files[0];
    if (fichier.size > 2 * 1024 * 1024) {
      window.alert('La photo ne doit pas dépasser 2 Mo.');
      input.value = '';
      return;
    }
    input.form.submit();
  });
});

// Animations réservées au frontoffice (le backoffice a une autre mise en page)
if (document.querySelector('nav.nav')) {

  // Transition de sortie entre les pages
  document.addEventListener('click', function (e) {
    var lien = e.target.closest('a[href]');
    if (!lien) return;
    var href = lien.getAttribute('href') || '';
    if (!href || href.startsWith('#') || lien.target === '_blank' || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if (/^(https?:|mailto:|tel:)/.test(href)) return;

    e.preventDefault();
    document.body.classList.add('sortie');
    setTimeout(function () { window.location.href = href; }, 250);
  });

  // Retour arrière du navigateur : on réaffiche la page
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) document.body.classList.remove('sortie');
  });

  // Onde au clic sur un bouton
  document.addEventListener('pointerdown', function (e) {
    var bouton = e.target.closest('button:not(:disabled), .btn');
    if (!bouton) return;

    var rect = bouton.getBoundingClientRect();
    var taille = Math.max(rect.width, rect.height);
    var onde = document.createElement('span');
    onde.className = 'ondulation';
    onde.style.width = onde.style.height = taille + 'px';
    onde.style.left = (e.clientX - rect.left - taille / 2) + 'px';
    onde.style.top = (e.clientY - rect.top - taille / 2) + 'px';
    bouton.appendChild(onde);
    setTimeout(function () { onde.remove(); }, 600);
  });
}
