<?php

require_once __DIR__ . '/config/database.php';

try {
  $email = "test@ferme.tn";

  $check = $pdo->prepare(
    "SELECT id FROM utilisateur WHERE email = :email"
  );

  $check->execute(['email' => $email]);

  if ($check->fetch()) {
    exit("Cet utilisateur existe déjà !");
  }

  $password = password_hash("Test@1234", PASSWORD_DEFAULT);

  $sql = "INSERT INTO utilisateur
        (nom, prenom, email, password, role)
        VALUES (:nom, :prenom, :email, :password, :role)";

  $stmt = $pdo->prepare($sql);

  $stmt->execute([
    'nom' => 'Test',
    'prenom' => 'Utilisateur',
    'email' => $email,
    'password' => $password,
    'role' => 'user'
  ]);

  echo "Utilisateur créé avec succès !";
} catch (PDOException $e) {
  die("Erreur SQL : " . $e->getMessage());
}
