@echo off
echo Copie des fichiers du profil vers C:\xamppp\htdocs\ferme-ui ...
xcopy "%~dp0*" "C:\xamppp\htdocs\ferme-ui\" /E /Y /H
echo.
echo Copie terminee.
echo Ouvre maintenant : http://localhost/ferme-ui/
pause
