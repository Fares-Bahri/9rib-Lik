-- Profil utilisateur (page "Mon profil")
-- À exécuter dans phpMyAdmin : base gestion_projet > onglet SQL.
-- Idempotent sous MariaDB (XAMPP) : les colonnes déjà présentes sont ignorées.

USE gestion_projet;

ALTER TABLE utilisateur
  ADD COLUMN IF NOT EXISTS type_user ENUM('consommateur', 'producteur') NOT NULL DEFAULT 'consommateur' AFTER role,
  ADD COLUMN IF NOT EXISTS photo VARCHAR(255) NULL AFTER type_user,
  ADD COLUMN IF NOT EXISTS langue VARCHAR(10) NOT NULL DEFAULT 'fr' AFTER photo,
  ADD COLUMN IF NOT EXISTS notification_email TINYINT(1) NOT NULL DEFAULT 1 AFTER langue,
  ADD COLUMN IF NOT EXISTS notification_site TINYINT(1) NOT NULL DEFAULT 1 AFTER notification_email;
