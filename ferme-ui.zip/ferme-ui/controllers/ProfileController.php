<?php

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/AuthController.php';

class ProfileController
{
    public const LANGUES = [
        'fr' => 'Français',
        'en' => 'English',
        'ar' => 'العربية',
        'de' => 'Deutsch',
    ];

    public const TYPES = [
        'consommateur' => 'Consommateur',
        'producteur'   => 'Producteur',
    ];

    private const AVATAR_REL = 'assets/uploads/avatars';
    private const MAX_AVATAR_BYTES = 2 * 1024 * 1024;

    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnexion();
    }

    // ---------------- INFORMATIONS PERSONNELLES ----------------
    public function updateInfos(UserModel $user, array $post): array
    {
        if (!AuthController::verifyCsrfToken($post['csrf_token'] ?? null)) {
            return ['Jeton de sécurité invalide. Veuillez réessayer.'];
        }

        $prenom = trim((string) ($post['prenom'] ?? ''));
        $nom    = trim((string) ($post['nom'] ?? ''));
        $email  = trim((string) ($post['email'] ?? ''));
        $type   = (string) ($post['type_user'] ?? $user->getTypeUser());

        // Le type consommateur/producteur ne concerne que les comptes utilisateur.
        if ($user->getRole() !== 'user') {
            $type = $user->getTypeUser();
        }

        $errors = [];
        if (!preg_match('/^[\p{L}\s\'\-]{2,50}$/u', $prenom) || !preg_match('/^[\p{L}\s\'\-]{2,50}$/u', $nom)) {
            $errors[] = "Nom et prénom : 2 à 50 caractères (lettres, espaces, ' ou -).";
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Adresse email invalide.';
        }
        if (!isset(self::TYPES[$type])) {
            $errors[] = 'Type de compte invalide.';
        }
        if (!empty($errors)) {
            return $errors;
        }

        $stmt = $this->db->prepare('SELECT id FROM utilisateur WHERE email = :email AND id <> :id LIMIT 1');
        $stmt->execute(['email' => $email, 'id' => $user->getId()]);
        if ($stmt->fetch()) {
            return ['Cet email est déjà utilisé par un autre compte.'];
        }

        $stmt = $this->db->prepare(
            'UPDATE utilisateur SET nom = :nom, prenom = :prenom, email = :email, type_user = :type_user WHERE id = :id'
        );
        $stmt->execute([
            'nom'       => $nom,
            'prenom'    => $prenom,
            'email'     => $email,
            'type_user' => $type,
            'id'        => $user->getId(),
        ]);

        $_SESSION['username'] = trim($prenom . ' ' . $nom);
        return [];
    }

    // ---------------- LANGUE + NOTIFICATIONS ----------------
    public function updatePreferences(UserModel $user, array $post): array
    {
        if (!AuthController::verifyCsrfToken($post['csrf_token'] ?? null)) {
            return ['Jeton de sécurité invalide. Veuillez réessayer.'];
        }

        $langue = (string) ($post['langue'] ?? $user->getLangue());
        if (!isset(self::LANGUES[$langue])) {
            return ['Langue non prise en charge.'];
        }

        $notifEmail = $user->getNotificationEmail();
        $notifSite  = $user->getNotificationSite();
        if ($user->getRole() === 'user') {
            $notifEmail = isset($post['notification_email']);
            $notifSite  = isset($post['notification_site']);
        }

        $stmt = $this->db->prepare(
            'UPDATE utilisateur
                SET langue = :langue,
                    notification_email = :notification_email,
                    notification_site = :notification_site
              WHERE id = :id'
        );
        $stmt->execute([
            'langue'             => $langue,
            'notification_email' => $notifEmail ? 1 : 0,
            'notification_site'  => $notifSite ? 1 : 0,
            'id'                 => $user->getId(),
        ]);

        $_SESSION['langue'] = $langue;
        return [];
    }

    // ---------------- MOT DE PASSE ----------------
    public function changePassword(UserModel $user, array $post): array
    {
        if (!AuthController::verifyCsrfToken($post['csrf_token'] ?? null)) {
            return ['Jeton de sécurité invalide. Veuillez réessayer.'];
        }

        $current = (string) ($post['current_password'] ?? '');
        $new     = (string) ($post['new_password'] ?? '');
        $confirm = (string) ($post['confirm_password'] ?? '');

        if ($current === '' || $new === '' || $confirm === '') {
            return ['Veuillez remplir les trois champs.'];
        }
        if (!password_verify($current, $user->getPassword())) {
            return ['Le mot de passe actuel est incorrect.'];
        }
        if (strlen($new) < 8) {
            return ['Le nouveau mot de passe doit contenir au moins 8 caractères.'];
        }
        if ($new !== $confirm) {
            return ['Les mots de passe ne correspondent pas.'];
        }
        if ($new === $current) {
            return ["Le nouveau mot de passe doit être différent de l'actuel."];
        }

        $stmt = $this->db->prepare('UPDATE utilisateur SET password = :password WHERE id = :id');
        $stmt->execute([
            'password' => password_hash($new, PASSWORD_DEFAULT),
            'id'       => $user->getId(),
        ]);

        // Nouvel identifiant de session après changement de mot de passe.
        session_regenerate_id(true);
        return [];
    }

    // ---------------- PHOTO DE PROFIL ----------------
    public function updateAvatar(UserModel $user, array $files, array $post): array
    {
        if (!AuthController::verifyCsrfToken($post['csrf_token'] ?? null)) {
            return ['Jeton de sécurité invalide. Veuillez réessayer.'];
        }

        $file = $files['avatar'] ?? null;
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return ['Choisissez une image avant de valider.'];
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ["L'envoi de l'image a échoué. Réessayez avec un fichier plus petit."];
        }
        if (($file['size'] ?? 0) > self::MAX_AVATAR_BYTES) {
            return ['La photo ne doit pas dépasser 2 Mo.'];
        }

        $info = @getimagesize($file['tmp_name']);
        $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
        $type = is_array($info) ? (int) ($info[2] ?? 0) : 0;
        if (!isset($allowed[$type])) {
            return ['Format non pris en charge. Utilisez une image JPG, PNG ou WebP.'];
        }

        $dir = $this->avatarDir();
        if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
            return ['Impossible de préparer le dossier des photos.'];
        }

        $name = 'avatar_' . $user->getId() . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$type];
        if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
            return ["Impossible d'enregistrer la photo. Vérifiez les droits du dossier."];
        }

        $relative = self::AVATAR_REL . '/' . $name;
        $stmt = $this->db->prepare('UPDATE utilisateur SET photo = :photo WHERE id = :id');
        $stmt->execute(['photo' => $relative, 'id' => $user->getId()]);

        $this->deletePhotoFile($user->getPhoto());
        return [];
    }

    public function removeAvatar(UserModel $user, array $post): array
    {
        if (!AuthController::verifyCsrfToken($post['csrf_token'] ?? null)) {
            return ['Jeton de sécurité invalide. Veuillez réessayer.'];
        }

        $stmt = $this->db->prepare('UPDATE utilisateur SET photo = NULL WHERE id = :id');
        $stmt->execute(['id' => $user->getId()]);

        $this->deletePhotoFile($user->getPhoto());
        return [];
    }

    private function avatarDir(): string
    {
        return __DIR__ . '/../' . self::AVATAR_REL;
    }

    private function deletePhotoFile(string $photo): void
    {
        $photo = str_replace('\\', '/', $photo);
        if ($photo === '' || !str_starts_with($photo, self::AVATAR_REL . '/')) {
            return;
        }

        $path = realpath(__DIR__ . '/../' . $photo);
        $dir  = realpath($this->avatarDir());
        if ($path === false || $dir === false) {
            return;
        }

        $dir = rtrim(str_replace('\\', '/', $dir), '/') . '/';
        $normalizedPath = str_replace('\\', '/', $path);
        if (str_starts_with($normalizedPath, $dir) && is_file($path)) {
            @unlink($path);
        }
    }
}
