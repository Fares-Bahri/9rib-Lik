<?php
/**
 * views/layout.php - Habillage FRONTOFFICE
 * Attend : $title (string), $content (string), $activeNav (string), $extraCss (array)
 */
$flash = flash();
$activeNav = $activeNav ?? '';
$extraCss = $extraCss ?? [];

$navNom = trim((string) ($_SESSION['username'] ?? ''));
$navInitiales = '';
if ($navNom !== '') {
    foreach (preg_split('/\s+/u', $navNom) as $mot) {
        if ($mot !== '') {
            $navInitiales .= mb_strtoupper(mb_substr($mot, 0, 1));
        }
    }
    $navInitiales = mb_substr($navInitiales, 0, 2);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'Ferme') ?></title>
<link rel="stylesheet" href="assets/css/front.css">
<?php foreach ($extraCss as $css): ?>
<link rel="stylesheet" href="<?= e($css) ?>">
<?php endforeach; ?>
</head>
<body>
<nav class="nav">
  <a class="marque" href="index.php?action=home">Du champ à l'assiette</a>
  <div class="nav-liens">
    <?php if (AuthController::isAuthenticated()): ?>
      <a href="index.php?action=fermes">Fermes</a>
      <?php if (AuthController::hasRole('admin')): ?><a href="index.php?action=admin_fermes">Espace admin</a><?php endif; ?>
      <a href="index.php?action=profile" class="<?= $activeNav === 'profile' ? 'on' : '' ?>"><span class="nav-initiales" aria-hidden="true"><?= e($navInitiales ?: '?') ?></span>Mon profil</a>
      <a href="index.php?action=logout" class="btn">Déconnexion</a>
    <?php else: ?>
      <a href="index.php?action=login">Connexion</a>
      <a href="index.php?action=register" class="btn">Inscription</a>
    <?php endif; ?>
  </div>
</nav>
<?php if ($flash): ?><div class="alert alert-success flash"><?= e($flash) ?></div><?php endif; ?>
<?= $content ?>
<footer>Projet Technologies Web 2A · Gestion des fermes</footer>
<script src="assets/js/app.js"></script>
</body>
</html>
