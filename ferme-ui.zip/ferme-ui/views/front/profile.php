<?php
/** views/front/profile.php - Attend : $user (UserModel), $errors (array), $activeForm (string) */
ob_start();

$isAdmin = $user->getRole() === 'admin';
$typeUser = $user->getTypeUser();
$typeLabel = ProfileController::TYPES[$typeUser] ?? 'Consommateur';
$langueLabel = ProfileController::LANGUES[$user->getLangue()] ?? 'Français';

$initiales = mb_strtoupper(mb_substr($user->getPrenom(), 0, 1) . mb_substr($user->getNom(), 0, 1));
if ($initiales === '') {
    $initiales = '?';
}
$photo = (string) $user->getPhoto();
$hasPhoto = $photo !== '' && is_file(__DIR__ . '/../../' . $photo);

$vInfos = fn(string $k, string $default): string => $activeForm === 'infos' ? (string) ($_POST[$k] ?? $default) : $default;
$prenomVal = $vInfos('prenom', $user->getPrenom());
$nomVal = $vInfos('nom', $user->getNom());
$emailVal = $vInfos('email', $user->getEmail());
$typeVal = $activeForm === 'infos' ? (string) ($_POST['type_user'] ?? $typeUser) : $typeUser;
if (!isset(ProfileController::TYPES[$typeVal])) {
    $typeVal = $typeUser;
}

$langueVal = $activeForm === 'preferences' ? (string) ($_POST['langue'] ?? $user->getLangue()) : $user->getLangue();
if (!isset(ProfileController::LANGUES[$langueVal])) {
    $langueVal = $user->getLangue();
}
$notifEmailVal = $activeForm === 'preferences' ? isset($_POST['notification_email']) : $user->getNotificationEmail();
$notifSiteVal  = $activeForm === 'preferences' ? isset($_POST['notification_site']) : $user->getNotificationSite();

$codeMembre = 'Membre #' . str_pad((string) $user->getId(), 4, '0', STR_PAD_LEFT);
?>
<main class="profil-page">
  <section class="profil-entete">
    <div class="couverture" aria-hidden="true">
      <span class="bulle b1"></span><span class="bulle b2"></span><span class="bulle b3"></span>
    </div>
    <div class="entete-contenu">
      <div class="avatar-bloc">
        <div class="avatar-grand">
          <?php if ($hasPhoto): ?>
            <img src="<?= e($photo) ?>" alt="Photo de profil de <?= e($user->getNomComplet()) ?>">
          <?php else: ?>
            <span aria-hidden="true"><?= e($initiales) ?></span>
          <?php endif; ?>
        </div>
        <form class="avatar-form" method="POST" action="index.php?action=profile" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="hidden" name="form" value="avatar">
          <label class="avatar-pastille" title="Changer la photo de profil">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3 7.5 5H5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2.5L15 3H9Zm3 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2.2a2.8 2.8 0 1 0 0 5.6 2.8 2.8 0 0 0 0-5.6Z"/></svg>
            <input type="file" name="avatar" accept="image/jpeg,image/png,image/webp" data-autosubmit aria-label="Choisir une nouvelle photo de profil">
          </label>
        </form>
      </div>

      <h1><?= e($user->getNomComplet()) ?></h1>
      <p class="code-membre"><?= e($codeMembre) ?></p>
      <div class="badges">
        <?php if ($isAdmin): ?>
          <span class="badge-p admin">Administrateur</span>
        <?php else: ?>
          <span class="badge-p <?= $typeUser === 'producteur' ? 'producteur' : '' ?>"><?= e($typeLabel) ?></span>
        <?php endif; ?>
        <span class="badge-p langue">Langue : <?= e($langueLabel) ?></span>
      </div>
      <p class="email-entete"><?= e($user->getEmail()) ?></p>
    </div>
  </section>

  <div class="profil-grille">
    <div class="profil-colonne">
      <section class="carte-profil" id="infos">
        <header>
          <h2>Informations élémentaires</h2>
          <p>Votre identité et votre type de compte sur la plateforme.</p>
        </header>
        <?php if ($activeForm === 'infos' && !empty($errors)): ?>
          <div class="alert alert-error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div>
        <?php endif; ?>
        <form method="POST" action="index.php?action=profile">
          <?= csrf_field() ?>
          <input type="hidden" name="form" value="infos">
          <div class="duo">
            <div class="champ">
              <label for="prenom">Prénom</label>
              <input type="text" id="prenom" name="prenom" required minlength="2" maxlength="50" value="<?= e($prenomVal) ?>">
            </div>
            <div class="champ">
              <label for="nom">Nom</label>
              <input type="text" id="nom" name="nom" required minlength="2" maxlength="50" value="<?= e($nomVal) ?>">
            </div>
          </div>
          <div class="champ">
            <label for="email">Adresse e-mail</label>
            <input type="email" id="email" name="email" required value="<?= e($emailVal) ?>" autocomplete="email">
          </div>

          <?php if (!$isAdmin): ?>
            <p class="section-titre">Type de compte</p>
            <div class="choix-type">
              <label class="type-option">
                <input type="radio" name="type_user" value="consommateur" <?= $typeVal === 'consommateur' ? 'checked' : '' ?>>
                <span class="type-puce" aria-hidden="true"></span>
                <span><strong>Consommateur</strong><small>Acheter des produits frais directement auprès des fermes.</small></span>
              </label>
              <label class="type-option">
                <input type="radio" name="type_user" value="producteur" <?= $typeVal === 'producteur' ? 'checked' : '' ?>>
                <span class="type-puce" aria-hidden="true"></span>
                <span><strong>Producteur</strong><small>Vendre et gérer les produits de votre exploitation.</small></span>
              </label>
            </div>
          <?php else: ?>
            <p class="note-admin">Compte administrateur : le type de compte et les notifications utilisateur ne s'appliquent pas.</p>
          <?php endif; ?>

          <div class="form-actions">
            <button type="submit" class="btn-principal">Enregistrer les modifications</button>
          </div>
        </form>
      </section>

      <section class="carte-profil" id="securite">
        <header>
          <h2>Sécurité</h2>
          <p>Changez le mot de passe de ce compte.</p>
        </header>
        <?php if ($activeForm === 'password' && !empty($errors)): ?>
          <div class="alert alert-error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div>
        <?php endif; ?>
        <form method="POST" action="index.php?action=profile">
          <?= csrf_field() ?>
          <input type="hidden" name="form" value="password">
          <div class="champ">
            <label for="current_password">Mot de passe actuel</label>
            <input type="password" id="current_password" name="current_password" required autocomplete="current-password">
          </div>
          <div class="champ">
            <label for="new_password">Nouveau mot de passe</label>
            <input type="password" id="new_password" name="new_password" required minlength="8" autocomplete="new-password">
            <small>8 caractères minimum.</small>
          </div>
          <div class="champ">
            <label for="confirm_password">Confirmer le nouveau mot de passe</label>
            <input type="password" id="confirm_password" name="confirm_password" required minlength="8" autocomplete="new-password">
          </div>
          <div class="form-actions">
            <button type="submit" class="btn-principal">Modifier le mot de passe</button>
          </div>
        </form>
      </section>
    </div>

    <div class="profil-colonne">
      <section class="carte-profil" id="preferences">
        <header>
          <h2>Paramètres système</h2>
          <p>Langue et notifications de votre compte.</p>
        </header>
        <?php if ($activeForm === 'preferences' && !empty($errors)): ?>
          <div class="alert alert-error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div>
        <?php endif; ?>
        <form method="POST" action="index.php?action=profile">
          <?= csrf_field() ?>
          <input type="hidden" name="form" value="preferences">

          <p class="section-titre">Langue de l'interface</p>
          <div class="langues" role="radiogroup" aria-label="Langue de l'interface">
            <?php foreach (ProfileController::LANGUES as $code => $label): ?>
              <label class="langue-option">
                <input type="radio" name="langue" value="<?= e($code) ?>" <?= $langueVal === $code ? 'checked' : '' ?>>
                <span class="langue-code"><?= e(mb_strtoupper($code)) ?></span>
                <span <?= $code === 'ar' ? 'lang="ar"' : '' ?>><?= e($label) ?></span>
              </label>
            <?php endforeach; ?>
          </div>

          <?php if (!$isAdmin): ?>
            <p class="section-titre">Notifications</p>
            <div class="notif-liste">
              <label class="notif-ligne">
                <span class="notif-texte">
                  <strong>Notifications par e-mail</strong>
                  <small><?= $typeUser === 'producteur' ? 'Recevoir les nouvelles commandes et demandes de vos clients.' : 'Recevoir le suivi de vos commandes et les offres des fermes.' ?></small>
                </span>
                <span class="interrupteur">
                  <input type="checkbox" name="notification_email" value="1" <?= $notifEmailVal ? 'checked' : '' ?>>
                  <span class="piste"></span>
                </span>
              </label>
              <label class="notif-ligne">
                <span class="notif-texte">
                  <strong>Notifications sur le site</strong>
                  <small><?= $typeUser === 'producteur' ? 'Alertes de commandes affichées dans votre espace.' : 'Afficher les alertes dans votre espace personnel.' ?></small>
                </span>
                <span class="interrupteur">
                  <input type="checkbox" name="notification_site" value="1" <?= $notifSiteVal ? 'checked' : '' ?>>
                  <span class="piste"></span>
                </span>
              </label>
            </div>
          <?php else: ?>
            <p class="note-admin">Les notifications administrateur sont gérées dans l'espace d'administration. Vous pouvez toutefois choisir votre langue d'affichage.</p>
          <?php endif; ?>

          <div class="form-actions">
            <button type="submit" class="btn-principal">Enregistrer les préférences</button>
          </div>
        </form>
      </section>

      <section class="carte-profil" id="photo">
        <header>
          <h2>Photo de profil</h2>
          <p>JPG, PNG ou WebP — 2 Mo maximum.</p>
        </header>
        <?php if (in_array($activeForm, ['avatar', 'avatar_delete'], true) && !empty($errors)): ?>
          <div class="alert alert-error"><?php foreach ($errors as $error): ?><div><?= e($error) ?></div><?php endforeach; ?></div>
        <?php endif; ?>
        <div class="photo-zone">
          <div class="avatar-apercu">
            <?php if ($hasPhoto): ?>
              <img src="<?= e($photo) ?>" alt="">
            <?php else: ?>
              <span aria-hidden="true"><?= e($initiales) ?></span>
            <?php endif; ?>
          </div>
          <div class="photo-actions">
            <form class="avatar-form" method="POST" action="index.php?action=profile" enctype="multipart/form-data">
              <?= csrf_field() ?>
              <input type="hidden" name="form" value="avatar">
              <label class="btn-fichier">
                Changer la photo
                <input type="file" name="avatar" accept="image/jpeg,image/png,image/webp" data-autosubmit aria-label="Choisir une nouvelle photo de profil">
              </label>
            </form>
            <?php if ($hasPhoto): ?>
              <form method="POST" action="index.php?action=profile" data-confirm="Retirer votre photo de profil ?">
                <?= csrf_field() ?>
                <input type="hidden" name="form" value="avatar_delete">
                <button type="submit" class="btn-secondaire">Retirer la photo</button>
              </form>
            <?php endif; ?>
          </div>
        </div>
      </section>
    </div>
  </div>
</main>
<?php
$content = ob_get_clean();
$title = 'Mon profil - Fermes';
$activeNav = 'profile';
$extraCss = ['assets/css/profile.css'];
require __DIR__ . '/../layout.php';
