<?php

declare(strict_types=1);

namespace App\Core\Security;

use App\Core\Session;

final class CsrfToken
{
    public function token(): string
    {
        Session::start();

        if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['csrf_token'];
    }

    public function isValid(mixed $requestToken): bool
    {
        Session::start();
        $sessionToken = $_SESSION['csrf_token'] ?? '';

        return is_string($sessionToken)
            && $sessionToken !== ''
            && is_string($requestToken)
            && hash_equals($sessionToken, $requestToken);
    }
}
