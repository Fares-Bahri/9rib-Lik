<?php

declare(strict_types=1);

namespace App\Core\Http;

final class Request
{
    public static function text(string $key, ?array $post = null): string
    {
        $post ??= $_POST;
        $value = $post[$key] ?? '';

        if (!is_string($value) || preg_match('//u', $value) !== 1) {
            return '';
        }

        return trim(str_replace(["\0", "\r\n", "\r"], ['', "\n", "\n"], $value));
    }

    public static function method(): string
    {
        return $_SERVER['REQUEST_METHOD'] ?? '';
    }
}
