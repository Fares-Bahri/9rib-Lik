<?php

declare(strict_types=1);

namespace App\Core\Storage;

use RuntimeException;

final class JsonStore
{
    public static function decode(string $contents): array
    {
        if (strncmp($contents, '<?php', 5) === 0) {
            $end = strpos($contents, '?>');
            if ($end === false) {
                throw new RuntimeException('Fichier de données invalide.');
            }
            $contents = substr($contents, $end + 2);
        }

        if (trim($contents) === '') {
            return [];
        }

        $data = json_decode($contents, true);
        if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
            throw new RuntimeException('Fichier de données invalide.');
        }

        return $data;
    }

    public static function encode(array $data): string
    {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if ($json === false) {
            throw new RuntimeException('Encodage du stockage impossible.');
        }

        return "<?php http_response_code(403); exit; ?>\n" . $json;
    }
}
