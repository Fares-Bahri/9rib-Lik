<?php

declare(strict_types=1);

define('APP_ROOT', __DIR__);
require APP_ROOT . '/bootstrap.php';

$config = require APP_ROOT . '/config.php';

$controller = new App\Controllers\RegistrationController(
    new App\Core\Security\CsrfToken(),
    new App\Models\RateLimiter($config),
    new App\Models\RegistrationRepository($config['storage_dir']),
    $config['storage_dir']
);

$controller->store();
