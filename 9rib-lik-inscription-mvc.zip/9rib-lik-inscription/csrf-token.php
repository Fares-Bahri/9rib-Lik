<?php

declare(strict_types=1);

define('APP_ROOT', __DIR__);
require APP_ROOT . '/bootstrap.php';

(new App\Controllers\CsrfController())->show();
