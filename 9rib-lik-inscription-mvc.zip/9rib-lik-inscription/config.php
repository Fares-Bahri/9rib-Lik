<?php

declare(strict_types=1);

return [
    'storage_dir' => __DIR__ . '/storage',
    'rate_limit_attempts' => 5,
    'rate_limit_window' => 600,
];
