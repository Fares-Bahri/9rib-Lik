<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Http\Request;
use RuntimeException;

final class Registration
{
    public const TITLES = ['', 'Mme', 'M.', 'Autre'];

    public const COUNTRIES = [
        'Maroc',
        'France',
        'Belgique',
        'Suisse',
        'Canada',
        'Algérie',
        'Tunisie',
        'Sénégal',
        'Côte d’Ivoire',
        'Espagne',
        'Autre',
    ];

    public const PREFERENCES = [
        'Fruits et légumes',
        'Produits laitiers',
        'Viande et œufs',
        'Miel et confitures',
        'Produits bio',
        'Artisanat local',
    ];

    public const FREQUENCIES = [
        'Chaque semaine',
        'Tous les 15 jours',
        'Une fois par mois',
        'Occasionnellement',
    ];

    public const PRODUCTION_TYPES = [
        'Maraîchage',
        'Arboriculture',
        'Élevage',
        'Apiculture',
        'Céréales',
        'Produits laitiers',
        'Polyculture',
        'Autre',
    ];

    private string $role = '';
    private string $title = '';
    private string $firstName = '';
    private string $lastName = '';
    private string $email = '';
    private string $phone = '';
    private string $address = '';
    private string $postalCode = '';
    private string $city = '';
    private string $country = '';
    private string $password = '';
    private string $passwordConfirm = '';
    private bool $newsletterOptIn = false;
    private bool $termsAccepted = false;
    private array $preferences = [];
    private string $frequency = '';
    private string $farmName = '';
    private string $productionType = '';
    private string $surfaceValue = '';
    private ?float $surface = null;
    private string $farmDescription = '';
    private string $certificationText = '';
    private array $certifications = [];
    private string $website = '';

    public static function options(): array
    {
        return [
            'titles' => self::TITLES,
            'countries' => self::COUNTRIES,
            'preferences' => self::PREFERENCES,
            'frequencies' => self::FREQUENCIES,
            'productionTypes' => self::PRODUCTION_TYPES,
        ];
    }

    public static function fromPost(array $post): self
    {
        $registration = new self();
        $registration->role = Request::text('role', $post);
        $registration->title = Request::text('title', $post);
        $registration->firstName = Request::text('first_name', $post);
        $registration->lastName = Request::text('last_name', $post);
        $registration->email = Request::text('email', $post);
        $registration->phone = Request::text('phone', $post);
        $registration->address = Request::text('address', $post);
        $registration->postalCode = Request::text('postal_code', $post);
        $registration->city = Request::text('city', $post);
        $registration->country = Request::text('country', $post);
        $registration->password = Request::text('password', $post);
        $registration->passwordConfirm = Request::text('password_confirm', $post);
        $registration->newsletterOptIn = ($post['newsletter'] ?? '') === '1';
        $registration->termsAccepted = ($post['terms'] ?? '') === '1';

        if ($registration->role === 'consumer') {
            $submittedPreferences = $post['preferences'] ?? [];
            if (is_array($submittedPreferences)) {
                foreach ($submittedPreferences as $preference) {
                    if (is_string($preference)
                        && in_array($preference, self::PREFERENCES, true)
                        && !in_array($preference, $registration->preferences, true)) {
                        $registration->preferences[] = $preference;
                    }
                }
            }

            $registration->frequency = Request::text('frequency', $post);
        }

        if ($registration->role === 'producer') {
            $registration->farmName = Request::text('farm_name', $post);
            $registration->productionType = Request::text('production_type', $post);
            $registration->farmDescription = Request::text('farm_description', $post);
            $registration->website = Request::text('website', $post);

            $registration->surfaceValue = str_replace(',', '.', Request::text('surface', $post));
            if (preg_match('/^\d{1,6}(?:\.\d{1,2})?$/', $registration->surfaceValue) === 1) {
                $registration->surface = (float) $registration->surfaceValue;
            }

            $registration->certificationText = Request::text('certifications', $post);
            if (self::textLength($registration->certificationText) <= 300) {
                foreach (explode(',', $registration->certificationText) as $certification) {
                    $certification = trim($certification);
                    if ($certification !== '') {
                        $registration->certifications[] = $certification;
                    }
                }
            }
        }

        return $registration;
    }

    public function validate(): array
    {
        $errors = [];

        if (!in_array($this->role, ['consumer', 'producer'], true)) {
            $errors['role'] = 'Sélectionnez un profil consommateur ou producteur.';
        }

        if (!in_array($this->title, self::TITLES, true)) {
            $errors['title'] = 'Sélectionnez une civilité valide.';
        }

        if (!self::validName($this->firstName)) {
            $errors['first_name'] = 'Le prénom doit contenir entre 2 et 80 caractères valides.';
        }

        if (!self::validName($this->lastName)) {
            $errors['last_name'] = 'Le nom doit contenir entre 2 et 80 caractères valides.';
        }

        if (self::textLength($this->email) > 180 || filter_var($this->email, FILTER_VALIDATE_EMAIL) === false) {
            $errors['email'] = 'Saisissez une adresse e-mail valide.';
        }

        $normalizedPhone = $this->normalizedPhone();
        if (self::textLength($this->phone) > 24 || preg_match('/^\+?[0-9]{8,15}$/', $normalizedPhone) !== 1) {
            $errors['phone'] = 'Saisissez un numéro de téléphone valide.';
        }

        if (self::textLength($this->address) < 5 || self::textLength($this->address) > 180) {
            $errors['address'] = 'L’adresse doit contenir entre 5 et 180 caractères.';
        }

        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9 -]{2,9}$/', $this->postalCode) !== 1) {
            $errors['postal_code'] = 'Saisissez un code postal valide.';
        }

        if (self::textLength($this->city) < 2 || self::textLength($this->city) > 80) {
            $errors['city'] = 'La ville doit contenir entre 2 et 80 caractères.';
        }

        if (!in_array($this->country, self::COUNTRIES, true)) {
            $errors['country'] = 'Sélectionnez un pays valide.';
        }

        if (self::textLength($this->password) < 8 || self::textLength($this->password) > 72) {
            $errors['password'] = 'Le mot de passe doit contenir entre 8 et 72 caractères.';
        } elseif (preg_match('/\p{L}/u', $this->password) !== 1 || preg_match('/[0-9]/', $this->password) !== 1) {
            $errors['password'] = 'Le mot de passe doit contenir au moins une lettre et un chiffre.';
        }

        if ($this->passwordConfirm === '' || !hash_equals($this->password, $this->passwordConfirm)) {
            $errors['password_confirm'] = 'Les deux mots de passe ne correspondent pas.';
        }

        if (!$this->termsAccepted) {
            $errors['terms'] = 'Vous devez accepter les conditions d’utilisation.';
        }

        if ($this->role === 'consumer') {
            if (!in_array($this->frequency, ['', ...self::FREQUENCIES], true)) {
                $errors['frequency'] = 'Sélectionnez une fréquence valide.';
            }
        }

        if ($this->role === 'producer') {
            if (self::textLength($this->farmName) < 2 || self::textLength($this->farmName) > 120) {
                $errors['farm_name'] = 'Le nom de la ferme doit contenir entre 2 et 120 caractères.';
            }

            if (!in_array($this->productionType, self::PRODUCTION_TYPES, true)) {
                $errors['production_type'] = 'Sélectionnez un type de production valide.';
            }

            if (preg_match('/^\d{1,6}(?:\.\d{1,2})?$/', $this->surfaceValue) !== 1) {
                $errors['surface'] = 'Indiquez une superficie valide.';
            } elseif ($this->surface === null || $this->surface < 0.1 || $this->surface > 100000) {
                $errors['surface'] = 'La superficie doit être comprise entre 0,1 et 100 000 hectares.';
            }

            if (self::textLength($this->farmDescription) < 30 || self::textLength($this->farmDescription) > 1200) {
                $errors['farm_description'] = 'La présentation doit contenir entre 30 et 1200 caractères.';
            }

            if ($this->website !== '') {
                $websiteParts = parse_url($this->website);
                if (self::textLength($this->website) > 255
                    || filter_var($this->website, FILTER_VALIDATE_URL) === false
                    || !is_array($websiteParts)
                    || !in_array($websiteParts['scheme'] ?? '', ['http', 'https'], true)
                    || empty($websiteParts['host'])) {
                    $errors['website'] = 'Saisissez une adresse internet valide commençant par http:// ou https://.';
                }
            }

            if (self::textLength($this->certificationText) > 300) {
                $errors['certifications'] = 'Le texte des certifications ne doit pas dépasser 300 caractères.';
            } elseif (count($this->certifications) > 8
                || count(array_filter($this->certifications, static fn (string $item): bool => self::textLength($item) > 60)) > 0) {
                $errors['certifications'] = 'Indiquez au maximum 8 certifications de 60 caractères chacune.';
            }
        }

        return $errors;
    }

    public function role(): string
    {
        return $this->role;
    }

    public function email(): string
    {
        return strtolower($this->email);
    }

    public function toRecord(): array
    {
        $passwordHash = password_hash($this->password, PASSWORD_DEFAULT);
        if ($passwordHash === false) {
            throw new RuntimeException('Hachage du mot de passe impossible.');
        }

        $now = gmdate('c');

        return [
            'id' => bin2hex(random_bytes(16)),
            'created_at' => $now,
            'role' => $this->role,
            'status' => 'active',
            'title' => $this->title,
            'first_name' => $this->firstName,
            'last_name' => $this->lastName,
            'email' => $this->email(),
            'phone' => $this->normalizedPhone(),
            'address' => $this->address,
            'postal_code' => $this->postalCode,
            'city' => $this->city,
            'country' => $this->country,
            'password_hash' => $passwordHash,
            'newsletter_opt_in' => $this->newsletterOptIn,
            'terms_accepted_at' => $now,
            'preferences' => $this->preferences,
            'frequency' => $this->frequency,
            'farm_name' => $this->farmName,
            'production_type' => $this->productionType,
            'surface_hectares' => $this->surface,
            'farm_description' => $this->farmDescription,
            'certifications' => $this->certifications,
            'website' => $this->website,
        ];
    }

    private function normalizedPhone(): string
    {
        return preg_replace('/[\s().-]+/', '', $this->phone) ?? '';
    }

    private static function validName(string $value): bool
    {
        return self::textLength($value) >= 2
            && self::textLength($value) <= 80
            && preg_match("/^[\\p{L}\\p{M}][\\p{L}\\p{M}\\s.'’\\-]{1,79}$/u", $value) === 1;
    }

    private static function textLength(string $value): int
    {
        if (function_exists('mb_strlen')) {
            return mb_strlen($value, 'UTF-8');
        }

        return preg_match_all('/./us', $value, $matches) ?: 0;
    }
}
