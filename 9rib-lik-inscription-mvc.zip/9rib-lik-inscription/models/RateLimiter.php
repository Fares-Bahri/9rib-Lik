<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Storage\JsonStore;
use RuntimeException;

final class RateLimiter
{
    private string $path;
    private int $attempts;
    private int $window;

    public function __construct(array $config)
    {
        $this->path = $config['storage_dir'] . '/rate-limit.php';
        $this->attempts = $config['rate_limit_attempts'];
        $this->window = $config['rate_limit_window'];
    }

    public function retryAfter(string $identifier): ?int
    {
        $handle = fopen($this->path, 'c+');
        if ($handle === false) {
            throw new RuntimeException('Stockage indisponible.');
        }

        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('Verrouillage du stockage impossible.');
            }

            $data = JsonStore::decode((string) stream_get_contents($handle));
            $now = time();
            $key = hash('sha256', '9rib-lik|' . $identifier);

            foreach ($data as $storedKey => $storedAttempts) {
                if (!is_array($storedAttempts)) {
                    unset($data[$storedKey]);
                    continue;
                }

                $storedAttempts = array_values(array_filter(
                    $storedAttempts,
                    fn ($attempt): bool => is_int($attempt) && $attempt >= $now - $this->window
                ));

                if ($storedAttempts !== []) {
                    $data[$storedKey] = $storedAttempts;
                } else {
                    unset($data[$storedKey]);
                }
            }

            $recentAttempts = $data[$key] ?? [];
            if (count($recentAttempts) >= $this->attempts) {
                return max(1, $this->window - ($now - min($recentAttempts)));
            }

            $recentAttempts[] = $now;
            $data[$key] = $recentAttempts;
            $json = JsonStore::encode($data);

            rewind($handle);
            ftruncate($handle, 0);
            $written = fwrite($handle, $json);
            if ($written === false || $written !== strlen($json)) {
                throw new RuntimeException('Écriture du stockage impossible.');
            }

            fflush($handle);
            return null;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
