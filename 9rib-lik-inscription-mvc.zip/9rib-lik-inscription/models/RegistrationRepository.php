<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Storage\JsonStore;
use RuntimeException;

final class RegistrationRepository
{
    private string $path;

    public function __construct(string $storageDirectory)
    {
        $this->path = $storageDirectory . '/registrations.php';
    }

    public function save(Registration $registration): bool
    {
        $record = $registration->toRecord();
        $handle = fopen($this->path, 'c+');
        if ($handle === false) {
            throw new RuntimeException('Création du registre impossible.');
        }

        try {
            if (!flock($handle, LOCK_EX)) {
                throw new RuntimeException('Verrouillage du registre impossible.');
            }

            $registrations = JsonStore::decode((string) stream_get_contents($handle));
            foreach ($registrations as $storedRegistration) {
                if (is_array($storedRegistration)
                    && strtolower((string) ($storedRegistration['email'] ?? '')) === $registration->email()) {
                    return false;
                }
            }

            $registrations[] = $record;
            $json = JsonStore::encode($registrations);

            rewind($handle);
            ftruncate($handle, 0);
            $written = fwrite($handle, $json);
            if ($written === false || $written !== strlen($json)) {
                throw new RuntimeException('Écriture du registre impossible.');
            }

            fflush($handle);
            return true;
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
    }
}
