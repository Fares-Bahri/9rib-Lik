(() => {
  "use strict";

  const form = document.getElementById("registration-form");
  const roleInputs = [...document.querySelectorAll(".role-input")];
  const consumerPanel = document.getElementById("consumer-panel");
  const producerPanel = document.getElementById("producer-panel");
  const summary = document.getElementById("form-summary");
  const summaryTitle = document.getElementById("summary-title");
  const summaryMessage = document.getElementById("summary-message");
  const errorList = document.getElementById("error-list");
  const status = document.getElementById("form-status");
  const submitButton = form.querySelector(".submit-button");
  const successPanel = document.getElementById("success-panel");
  const successTitle = document.getElementById("success-title");
  const successMessage = document.getElementById("success-message");
  const successRole = document.getElementById("success-role");
  const description = document.getElementById("farm-description");
  const descriptionCount = document.getElementById("description-count");
  const currentYear = document.getElementById("current-year");
  const config = JSON.parse(document.getElementById("registration-config").textContent);
  const preferences = config.preferences;
  const productionTypes = config.productionTypes;
  const frequencies = config.frequencies;
  const titles = config.titles;
  let selectedRole = "consumer";
  let csrfToken = "";
  let isSubmitting = false;

  const field = (name) => form.elements.namedItem(name);
  const value = (name) => String(field(name)?.value ?? "").trim();
  const isVisible = (element) => Boolean(element && !element.disabled && element.getClientRects().length);

  function setPanelState(panel, enabled) {
    panel.hidden = !enabled;
    panel.querySelectorAll("input, select, textarea").forEach((element) => {
      element.disabled = !enabled;
    });
  }

  function setRole(role) {
    selectedRole = role === "producer" ? "producer" : "consumer";
    roleInputs.forEach((input) => {
      input.checked = input.value === selectedRole;
    });
    setPanelState(consumerPanel, selectedRole === "consumer");
    setPanelState(producerPanel, selectedRole === "producer");
    clearErrors();
    status.textContent = "";
  }

  function errorElement(name) {
    return form.querySelector(`[data-error-for="${name}"]`);
  }

  function setFieldError(name, message) {
    const input = field(name);
    const error = errorElement(name);
    if (input && "setAttribute" in input) {
      input.setAttribute("aria-invalid", "true");
    }
    if (error) {
      error.textContent = message;
    }
  }

  function clearFieldError(name) {
    const input = field(name);
    const error = errorElement(name);
    if (input && "removeAttribute" in input) {
      input.removeAttribute("aria-invalid");
    }
    if (error) {
      error.textContent = "";
    }
  }

  function clearErrors() {
    form.querySelectorAll('[aria-invalid="true"]').forEach((input) => input.removeAttribute("aria-invalid"));
    form.querySelectorAll(".field-error").forEach((error) => {
      error.textContent = "";
    });
    summary.hidden = true;
    errorList.replaceChildren();
  }

  function showSummary(title, message, errors) {
    summaryTitle.textContent = title;
    summaryMessage.textContent = message;
    errorList.replaceChildren();
    Object.entries(errors).forEach(([name, text]) => {
      const item = document.createElement("li");
      const label = field(name)?.closest(".field, .consent")?.querySelector("label")?.textContent.trim().replace(/\s+/g, " ") || "Profil";
      item.textContent = `${label.replace(/\s*\*\s*$/, "")} : ${text}`;
      errorList.append(item);
    });
    summary.hidden = false;
    summary.focus({ preventScroll: true });
    summary.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function validateField(name) {
    const raw = value(name);
    let message = "";

    switch (name) {
      case "title":
        if (!titles.includes(raw)) message = "Sélectionnez une civilité valide.";
        break;
      case "first_name":
      case "last_name":
        if (!raw) message = "Ce champ est obligatoire.";
        else if (!/^[\p{L}\p{M}][\p{L}\p{M}\s.'’\-]{1,79}$/u.test(raw)) message = "Utilisez au moins 2 caractères, sans chiffre.";
        break;
      case "email":
        if (!raw) message = "Votre adresse e-mail est obligatoire.";
        else if (raw.length > 180 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(raw)) message = "Saisissez une adresse e-mail valide.";
        break;
      case "phone": {
        const digits = raw.replace(/\D/g, "");
        if (!raw) message = "Votre numéro de téléphone est obligatoire.";
        else if (!/^\+?[\d\s().-]{8,24}$/.test(raw) || digits.length < 8 || digits.length > 15) message = "Saisissez un numéro de téléphone valide.";
        break;
      }
      case "address":
        if (!raw) message = "Votre adresse est obligatoire.";
        else if (raw.length < 5 || raw.length > 180) message = "L’adresse doit contenir entre 5 et 180 caractères.";
        break;
      case "postal_code":
        if (!raw) message = "Votre code postal est obligatoire.";
        else if (!/^[A-Za-z0-9][A-Za-z0-9 -]{2,9}$/.test(raw)) message = "Saisissez un code postal valide.";
        break;
      case "city":
        if (!raw) message = "Votre ville est obligatoire.";
        else if (raw.length < 2 || raw.length > 80) message = "La ville doit contenir entre 2 et 80 caractères.";
        break;
      case "country":
        if (!raw) message = "Sélectionnez votre pays.";
        break;
      case "password":
        if (!raw) message = "Choisissez un mot de passe.";
        else if (raw.length < 8 || raw.length > 72) message = "Le mot de passe doit contenir entre 8 et 72 caractères.";
        else if (!/[\p{L}]/u.test(raw) || !/\d/.test(raw)) message = "Ajoutez au moins une lettre et un chiffre.";
        break;
      case "password_confirm":
        if (!raw) message = "Confirmez votre mot de passe.";
        else if (raw !== value("password")) message = "Les deux mots de passe ne correspondent pas.";
        break;
      case "frequency":
        if (raw && !frequencies.includes(raw)) message = "Sélectionnez une fréquence valide.";
        break;
      case "farm_name":
        if (!raw) message = "Indiquez le nom de votre ferme.";
        else if (raw.length < 2 || raw.length > 120) message = "Le nom de la ferme doit contenir entre 2 et 120 caractères.";
        break;
      case "production_type":
        if (!productionTypes.includes(raw)) message = "Sélectionnez un type de production.";
        break;
      case "surface": {
        const surface = Number(raw);
        if (raw === "" || !Number.isFinite(surface)) message = "Indiquez la superficie de votre ferme.";
        else if (surface < 0.1 || surface > 100000) message = "La superficie doit être comprise entre 0,1 et 100 000 hectares.";
        break;
      }
      case "farm_description":
        if (!raw) message = "Présentez votre ferme.";
        else if (raw.length < 30 || raw.length > 1200) message = "La présentation doit contenir entre 30 et 1200 caractères.";
        break;
      case "certifications": {
        const items = raw ? raw.split(",").map((item) => item.trim()).filter(Boolean) : [];
        if (raw.length > 300) message = "Le texte des certifications ne doit pas dépasser 300 caractères.";
        else if (items.length > 8 || items.some((item) => item.length > 60)) message = "Indiquez au maximum 8 certifications de 60 caractères chacune.";
        break;
      }
      case "website":
        if (raw) {
          try {
            const url = new URL(raw);
            if (!["http:", "https:"].includes(url.protocol) || !url.hostname) throw new Error("URL invalide");
          } catch {
            message = "Saisissez une adresse complète commençant par https:// ou http://.";
          }
        }
        break;
      case "terms":
        if (!field(name).checked) message = "Vous devez accepter les conditions pour continuer.";
        break;
      default:
        break;
    }

    clearFieldError(name);
    if (message) setFieldError(name, message);
    return message;
  }

  function validateForm() {
    clearErrors();
    const errors = {};
    const commonFields = ["title", "first_name", "last_name", "email", "phone", "address", "postal_code", "city", "country", "password", "password_confirm", "terms"];
    const specificFields = selectedRole === "consumer" ? ["frequency"] : ["farm_name", "production_type", "surface", "farm_description", "certifications", "website"];

    [...commonFields, ...specificFields].forEach((name) => {
      const message = validateField(name);
      if (message) errors[name] = message;
    });

    if (Object.keys(errors).length) {
      const count = Object.keys(errors).length;
      showSummary("Vérifiez les informations suivantes", `${count} champ${count > 1 ? "s" : ""} à corriger avant l’envoi.`, errors);
      const firstInvalid = form.querySelector('[aria-invalid="true"]');
      firstInvalid?.focus();
      return false;
    }
    return true;
  }

  async function loadCsrfToken() {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch("csrf-token.php", {
        method: "GET",
        credentials: "same-origin",
        cache: "no-store",
        headers: { Accept: "application/json" },
        signal: controller.signal
      });
      if (!response.ok) throw new Error("Jeton indisponible");
      const data = await response.json();
      if (typeof data.csrfToken !== "string" || !data.csrfToken) throw new Error("Jeton invalide");
      csrfToken = data.csrfToken;
      field("csrf_token").value = csrfToken;
    } catch {
      csrfToken = "";
    } finally {
      window.clearTimeout(timeout);
    }
  }

  function setSubmitting(submitting) {
    isSubmitting = submitting;
    submitButton.disabled = submitting;
    submitButton.classList.toggle("is-loading", submitting);
    form.setAttribute("aria-busy", String(submitting));
    if (submitting) {
      status.textContent = "Enregistrement de vos informations…";
    }
  }

  function showSuccess(data) {
    status.textContent = "";
    form.hidden = true;
    successPanel.hidden = false;
    successMessage.textContent = data.message || "Votre compte a bien été créé. Merci de rejoindre notre communauté.";
    successRole.textContent = data.role === "producer" ? "Profil producteur" : "Profil consommateur";
    successTitle.focus();
    successPanel.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  roleInputs.forEach((input) => {
    input.addEventListener("change", () => {
      if (!input.checked) {
        input.checked = true;
        return;
      }
      setRole(input.value);
    });
  });

  document.querySelectorAll("[data-select-role]").forEach((button) => {
    button.addEventListener("click", () => {
      setRole(button.dataset.selectRole);
      document.getElementById("inscription").scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  form.addEventListener("input", (event) => {
    const target = event.target;
    if (target.name && target.getAttribute("aria-invalid") === "true") {
      clearFieldError(target.name);
      status.textContent = "";
    }
    if (target === description) {
      descriptionCount.textContent = String(target.value.length);
    }
  });

  form.addEventListener("change", (event) => {
    if (event.target.name && isVisible(event.target)) {
      validateField(event.target.name);
    }
  });

  form.addEventListener("focusout", (event) => {
    const target = event.target;
    if (target.name && isVisible(target) && ["INPUT", "SELECT", "TEXTAREA"].includes(target.tagName) && target.type !== "checkbox") {
      validateField(target.name);
    }
  });

  document.querySelectorAll("[data-toggle-password]").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.togglePassword);
      const reveal = input.type === "password";
      input.type = reveal ? "text" : "password";
      button.textContent = reveal ? "Masquer" : "Afficher";
      button.setAttribute("aria-pressed", String(reveal));
      button.setAttribute("aria-label", reveal ? "Masquer le mot de passe" : "Afficher le mot de passe");
    });
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (isSubmitting) return;
    status.textContent = "";
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      if (!csrfToken) await loadCsrfToken();
      if (!csrfToken) throw new Error("Le serveur de sécurité ne répond pas. Vérifiez que la page est ouverte via PHP, puis réessayez.");

      const formData = new FormData(form);
      formData.set("csrf_token", csrfToken);
      const response = await fetch(form.action, {
        method: "POST",
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        body: formData
      });
      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const serverErrors = data.errors && typeof data.errors === "object" ? data.errors : {};
        const fieldErrors = {};
        Object.entries(serverErrors).forEach(([name, message]) => {
          if (name === "_form") status.textContent = String(message);
          else {
            fieldErrors[name] = String(message);
            setFieldError(name, String(message));
          }
        });
        if (Object.keys(fieldErrors).length) {
          showSummary("Vérifiez les informations suivantes", "Certaines informations doivent être corrigées.", fieldErrors);
          form.querySelector('[aria-invalid="true"]')?.focus();
        } else if (!status.textContent) {
          throw new Error(data.message || "L’inscription n’a pas pu être enregistrée. Veuillez réessayer.");
        }
        return;
      }

      if (!data.success) throw new Error(data.message || "L’inscription n’a pas pu être confirmée.");
      form.reset();
      csrfToken = "";
      showSuccess(data);
    } catch (error) {
      status.textContent = error instanceof Error ? error.message : "Une erreur est survenue. Veuillez réessayer.";
    } finally {
      setSubmitting(false);
    }
  });

  document.getElementById("new-registration").addEventListener("click", () => {
    form.reset();
    clearErrors();
    successPanel.hidden = true;
    form.hidden = false;
    setRole("consumer");
    descriptionCount.textContent = "0";
    csrfToken = "";
    document.getElementById("registration-title").scrollIntoView({ behavior: "smooth", block: "start" });
    loadCsrfToken();
  });

  currentYear.textContent = String(new Date().getFullYear());
  setRole("consumer");
  loadCsrfToken();
})();
