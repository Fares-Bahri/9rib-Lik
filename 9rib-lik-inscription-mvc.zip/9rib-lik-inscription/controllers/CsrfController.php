<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Http\Response;
use App\Core\Security\CsrfToken;

final class CsrfController
{
    public function show(): void
    {
        Response::json(200, ['csrfToken' => (new CsrfToken())->token()]);
    }
}
