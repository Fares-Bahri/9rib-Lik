<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Registration;

final class HomeController
{
    public function index(): void
    {
        $options = Registration::options();
        $currentYear = date('Y');

        require APP_ROOT . '/views/pages/registration.php';
    }
}
