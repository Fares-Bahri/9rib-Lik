<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Security\CsrfToken;
use App\Models\RateLimiter;
use App\Models\Registration;
use App\Models\RegistrationRepository;
use RuntimeException;
use Throwable;

final class RegistrationController
{
    private CsrfToken $csrfToken;
    private RateLimiter $rateLimiter;
    private RegistrationRepository $registrations;
    private string $storageDirectory;

    public function __construct(
        CsrfToken $csrfToken,
        RateLimiter $rateLimiter,
        RegistrationRepository $registrations,
        string $storageDirectory
    ) {
        $this->csrfToken = $csrfToken;
        $this->rateLimiter = $rateLimiter;
        $this->registrations = $registrations;
        $this->storageDirectory = $storageDirectory;
    }

    public function store(): void
    {
        try {
            if (Request::method() !== 'POST') {
                header('Allow: POST');
                Response::json(405, ['success' => false, 'message' => 'Méthode non autorisée.']);
            }

            if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 100000) {
                Response::json(413, ['success' => false, 'message' => 'La demande est trop volumineuse.']);
            }

            $this->checkOrigin();

            if (!$this->csrfToken->isValid($_POST['csrf_token'] ?? '')) {
                Response::json(403, [
                    'success' => false,
                    'message' => 'Votre session a expiré. Rechargez la page puis réessayez.',
                ]);
            }

            if (Request::text('bot_field') !== '') {
                Response::json(200, [
                    'success' => true,
                    'message' => 'Votre demande a bien été prise en compte.',
                    'role' => 'consumer',
                ]);
            }

            if (!is_dir($this->storageDirectory) || !is_writable($this->storageDirectory)) {
                throw new RuntimeException('Dossier de stockage non accessible en écriture.');
            }

            $retryAfter = $this->rateLimiter->retryAfter($_SERVER['REMOTE_ADDR'] ?? 'unknown');
            if ($retryAfter !== null) {
                header('Retry-After: ' . $retryAfter);
                Response::json(429, [
                    'success' => false,
                    'message' => 'Trop de tentatives. Veuillez patienter quelques minutes avant de réessayer.',
                ]);
            }

            $registration = Registration::fromPost($_POST);
            $errors = $registration->validate();
            if ($errors !== []) {
                Response::json(422, [
                    'success' => false,
                    'message' => 'Certaines informations sont invalides.',
                    'errors' => $errors,
                ]);
            }

            if (!$this->registrations->save($registration)) {
                Response::json(422, [
                    'success' => false,
                    'message' => 'Cette adresse e-mail est déjà utilisée.',
                    'errors' => ['email' => 'Un compte existe déjà avec cette adresse e-mail.'],
                ]);
            }

            Response::json(201, [
                'success' => true,
                'message' => 'Votre compte a bien été créé. Merci de rejoindre la communauté 9rib Lik.',
                'role' => $registration->role(),
            ]);
        } catch (Throwable $exception) {
            error_log('9rib Lik registration error: ' . $exception->getMessage());
            Response::json(500, [
                'success' => false,
                'message' => 'Le service est momentanément indisponible. Veuillez réessayer plus tard.',
            ]);
        }
    }

    private function checkOrigin(): void
    {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === '' || $origin === 'null') {
            return;
        }

        $scheme = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        $expectedOrigin = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? '');

        if (!hash_equals(strtolower($expectedOrigin), strtolower($origin))) {
            Response::json(403, [
                'success' => false,
                'message' => 'Origine de la demande non autorisée.',
            ]);
        }
    }
}
