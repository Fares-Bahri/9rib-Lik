<?php

if (!defined('APP_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Créez votre compte 9rib Lik et rejoignez les consommateurs et producteurs qui font vivre les fermes locales.">
  <meta name="theme-color" content="#f6f4ec">
  <title>Créer un compte — 9rib Lik</title>
  <link rel="icon" href="assets/images/9rib-lik.jpg" type="image/jpeg">
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/formulaire.js" defer></script>
  <script id="registration-config" type="application/json"><?= json_encode($options, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
</head>
<body>
  <header class="site-header">
    <div class="header-inner">
      <a class="brand" href="#accueil" aria-label="9rib Lik — Accueil">
        <img src="assets/images/9rib-lik.jpg" width="88" height="88" alt="9rib Lik">
      </a>
      <nav class="main-nav" aria-label="Navigation principale">
        <a href="#avantages">Pourquoi 9rib Lik ?</a>
        <button type="button" data-select-role="producer">Devenir producteur</button>
        <a class="button button-small" href="#inscription">Créer un compte</a>
      </nav>
    </div>
  </header>

  <main id="accueil">
