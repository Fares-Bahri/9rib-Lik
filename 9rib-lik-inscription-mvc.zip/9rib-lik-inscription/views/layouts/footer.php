<?php

if (!defined('APP_ROOT')) {
    http_response_code(404);
    exit;
}
?>
  </main>

  <footer class="site-footer">
    <div class="footer-inner">
      <img src="assets/images/9rib-lik.jpg" width="64" height="64" alt="9rib Lik">
      <p>Du champ à l’assiette, cultivons le lien.</p>
      <span>© <span id="current-year"><?= e($currentYear) ?></span> 9rib Lik</span>
    </div>
  </footer>
</body>
</html>
