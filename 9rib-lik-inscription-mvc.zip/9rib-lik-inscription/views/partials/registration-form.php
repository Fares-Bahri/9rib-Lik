<?php

if (!defined('APP_ROOT')) {
    http_response_code(404);
    exit;
}
?>
<?php $titleLabels = ['' => 'À préciser', 'Mme' => 'Madame', 'M.' => 'Monsieur', 'Autre' => 'Autre']; ?>
<form id="registration-form" action="register.php" method="post" novalidate>
  <input type="hidden" name="csrf_token" value="">
  <fieldset class="role-fieldset">
    <legend class="sr-only">Quel est votre profil ?</legend>
    <label class="role-card" for="role-consumer">
      <input class="role-input" type="checkbox" id="role-consumer" name="role" value="consumer" checked aria-controls="consumer-panel" aria-describedby="role-help">
      <span class="role-check" aria-hidden="true"></span>
      <span class="role-copy">
        <strong>Consommateur</strong>
        <span>Je souhaite découvrir et acheter des produits locaux.</span>
      </span>
      <span class="role-tag">Je découvre</span>
    </label>
    <label class="role-card" for="role-producer">
      <input class="role-input" type="checkbox" id="role-producer" name="role" value="producer" aria-controls="producer-panel" aria-describedby="role-help">
      <span class="role-check" aria-hidden="true"></span>
      <span class="role-copy">
        <strong>Producteur</strong>
        <span>Je souhaite présenter et vendre les produits de ma ferme.</span>
      </span>
      <span class="role-tag">Je propose</span>
    </label>
  </fieldset>

  <div class="form-summary" id="form-summary" role="alert" tabindex="-1" hidden>
    <strong id="summary-title">Vérifiez les informations suivantes</strong>
    <span id="summary-message"></span>
    <ul id="error-list"></ul>
  </div>

  <div class="honeypot" aria-hidden="true">
    <label for="bot-field">Votre site internet</label>
    <input id="bot-field" name="bot_field" type="text" tabindex="-1" autocomplete="off">
  </div>

  <section class="form-section" aria-labelledby="personal-title">
    <div class="section-heading">
      <span class="step-number" aria-hidden="true">01</span>
      <div>
        <h3 id="personal-title">Vos informations personnelles</h3>
        <p>Les champs marqués d’un astérisque sont obligatoires.</p>
      </div>
    </div>

    <div class="field-grid">
      <div class="field">
        <label for="title">Civilité <span class="optional">(facultatif)</span></label>
        <select id="title" name="title">
          <?php foreach ($options['titles'] as $title): ?>
            <option value="<?= e($title) ?>"><?= e($titleLabels[$title]) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-error" data-error-for="title"></span>
      </div>
      <div class="field">
        <label for="first-name">Prénom <span aria-hidden="true">*</span></label>
        <input id="first-name" name="first_name" type="text" autocomplete="given-name" maxlength="80" required aria-describedby="first-name-error">
        <span class="field-error" id="first-name-error" data-error-for="first_name"></span>
      </div>
      <div class="field">
        <label for="last-name">Nom <span aria-hidden="true">*</span></label>
        <input id="last-name" name="last_name" type="text" autocomplete="family-name" maxlength="80" required aria-describedby="last-name-error">
        <span class="field-error" id="last-name-error" data-error-for="last_name"></span>
      </div>
      <div class="field">
        <label for="email">Adresse e-mail <span aria-hidden="true">*</span></label>
        <input id="email" name="email" type="email" inputmode="email" autocomplete="email" maxlength="180" required aria-describedby="email-error">
        <span class="field-error" id="email-error" data-error-for="email"></span>
      </div>
      <div class="field">
        <label for="phone">Téléphone <span aria-hidden="true">*</span></label>
        <input id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="24" placeholder="Ex. +212 6 12 34 56 78" required aria-describedby="phone-error">
        <span class="field-error" id="phone-error" data-error-for="phone"></span>
      </div>
      <div class="field">
        <label for="address">Adresse <span aria-hidden="true">*</span></label>
        <input id="address" name="address" type="text" autocomplete="street-address" maxlength="180" required aria-describedby="address-error">
        <span class="field-error" id="address-error" data-error-for="address"></span>
      </div>
      <div class="field">
        <label for="postal-code">Code postal <span aria-hidden="true">*</span></label>
        <input id="postal-code" name="postal_code" type="text" inputmode="numeric" autocomplete="postal-code" maxlength="10" required aria-describedby="postal-code-error">
        <span class="field-error" id="postal-code-error" data-error-for="postal_code"></span>
      </div>
      <div class="field">
        <label for="city">Ville <span aria-hidden="true">*</span></label>
        <input id="city" name="city" type="text" autocomplete="address-level2" maxlength="80" required aria-describedby="city-error">
        <span class="field-error" id="city-error" data-error-for="city"></span>
      </div>
      <div class="field">
        <label for="country">Pays <span aria-hidden="true">*</span></label>
        <select id="country" name="country" autocomplete="country-name" required aria-describedby="country-error">
          <option value="">Sélectionnez votre pays</option>
          <?php foreach ($options['countries'] as $country): ?>
            <option value="<?= e($country) ?>"<?= $country === 'Maroc' ? ' selected' : '' ?>><?= e($country) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-error" id="country-error" data-error-for="country"></span>
      </div>
      <div class="field">
        <label for="password">Mot de passe <span aria-hidden="true">*</span></label>
        <div class="password-control">
          <input id="password" name="password" type="password" autocomplete="new-password" minlength="8" maxlength="72" required aria-describedby="password-hint password-error">
          <button type="button" data-toggle-password="password" aria-label="Afficher le mot de passe" aria-pressed="false">Afficher</button>
        </div>
        <span class="field-hint" id="password-hint">8 caractères minimum, avec au moins une lettre et un chiffre.</span>
        <span class="field-error" id="password-error" data-error-for="password"></span>
      </div>
      <div class="field">
        <label for="password-confirm">Confirmer le mot de passe <span aria-hidden="true">*</span></label>
        <div class="password-control">
          <input id="password-confirm" name="password_confirm" type="password" autocomplete="new-password" minlength="8" maxlength="72" required aria-describedby="password-confirm-error">
          <button type="button" data-toggle-password="password-confirm" aria-label="Afficher la confirmation" aria-pressed="false">Afficher</button>
        </div>
        <span class="field-error" id="password-confirm-error" data-error-for="password_confirm"></span>
      </div>
    </div>
  </section>

  <section class="form-section specific-panel" id="consumer-panel" aria-labelledby="consumer-title">
    <div class="section-heading">
      <span class="step-number" aria-hidden="true">02</span>
      <div>
        <h3 id="consumer-title">Vos préférences de consommateur</h3>
        <p>Pour vous proposer les producteurs qui correspondent à vos envies.</p>
      </div>
    </div>

    <fieldset class="preference-fieldset">
      <legend>Quels produits vous intéressent ? <span class="optional">(facultatif)</span></legend>
      <div class="checkbox-grid">
        <?php foreach ($options['preferences'] as $preference): ?>
          <label class="check-card"><input type="checkbox" name="preferences[]" value="<?= e($preference) ?>"><span><?= e($preference) ?></span></label>
        <?php endforeach; ?>
      </div>
    </fieldset>

    <div class="field-grid single-column">
      <div class="field">
        <label for="frequency">À quelle fréquence souhaitez-vous acheter ? <span class="optional">(facultatif)</span></label>
        <select id="frequency" name="frequency">
          <option value="">Je ne sais pas encore</option>
          <?php foreach ($options['frequencies'] as $frequency): ?>
            <option value="<?= e($frequency) ?>"><?= e($frequency) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-error" data-error-for="frequency"></span>
      </div>
    </div>
  </section>

  <section class="form-section specific-panel" id="producer-panel" aria-labelledby="producer-title" hidden>
    <div class="section-heading">
      <span class="step-number" aria-hidden="true">02</span>
      <div>
        <h3 id="producer-title">Votre ferme</h3>
        <p>Présentez votre exploitation aux consommateurs de votre région.</p>
      </div>
    </div>

    <div class="field-grid">
      <div class="field">
        <label for="farm-name">Nom de la ferme <span aria-hidden="true">*</span></label>
        <input id="farm-name" name="farm_name" type="text" autocomplete="organization" maxlength="120" required aria-describedby="farm-name-error" disabled>
        <span class="field-error" id="farm-name-error" data-error-for="farm_name"></span>
      </div>
      <div class="field">
        <label for="production-type">Type de production <span aria-hidden="true">*</span></label>
        <select id="production-type" name="production_type" required aria-describedby="production-type-error" disabled>
          <option value="">Sélectionnez une production</option>
          <?php foreach ($options['productionTypes'] as $productionType): ?>
            <option value="<?= e($productionType) ?>"><?= e($productionType) ?></option>
          <?php endforeach; ?>
        </select>
        <span class="field-error" id="production-type-error" data-error-for="production_type"></span>
      </div>
      <div class="field">
        <label for="surface">Superficie de la ferme (en hectares) <span aria-hidden="true">*</span></label>
        <input id="surface" name="surface" type="number" inputmode="decimal" min="0.1" max="100000" step="0.1" required aria-describedby="surface-error" disabled>
        <span class="field-error" id="surface-error" data-error-for="surface"></span>
      </div>
      <div class="field">
        <label for="website">Site internet <span class="optional">(facultatif)</span></label>
        <input id="website" name="website" type="url" inputmode="url" autocomplete="url" maxlength="255" placeholder="https://exemple.com" aria-describedby="website-error" disabled>
        <span class="field-error" id="website-error" data-error-for="website"></span>
      </div>
      <div class="field field-full">
        <label for="farm-description">Présentez votre ferme <span aria-hidden="true">*</span></label>
        <textarea id="farm-description" name="farm_description" rows="5" minlength="30" maxlength="1200" placeholder="Parlez-nous de vos productions, de votre mode de culture et de votre engagement…" required aria-describedby="farm-description-hint farm-description-error" disabled></textarea>
        <span class="field-hint" id="farm-description-hint"><span id="description-count">0</span> / 1200 caractères — 30 minimum.</span>
        <span class="field-error" id="farm-description-error" data-error-for="farm_description"></span>
      </div>
      <div class="field field-full">
        <label for="certifications">Certifications ou labels <span class="optional">(facultatif)</span></label>
        <input id="certifications" name="certifications" type="text" maxlength="300" placeholder="Ex. Bio, Ecocert, GlobalG.A.P." aria-describedby="certifications-hint certifications-error" disabled>
        <span class="field-hint" id="certifications-hint">Séparez les certifications par des virgules.</span>
        <span class="field-error" id="certifications-error" data-error-for="certifications"></span>
      </div>
    </div>
  </section>

  <section class="form-section consent-section" aria-label="Préférences et validation">
    <label class="consent">
      <input type="checkbox" name="terms" value="1" required aria-describedby="terms-error">
      <span>J’accepte les conditions d’utilisation et la politique de confidentialité de 9rib Lik. <span aria-hidden="true">*</span></span>
    </label>
    <span class="field-error" id="terms-error" data-error-for="terms"></span>
    <label class="consent consent-optional">
      <input type="checkbox" name="newsletter" value="1">
      <span>Je souhaite recevoir les actualités, conseils et offres de 9rib Lik. <span class="optional">(facultatif)</span></span>
    </label>
    <div class="submit-row">
      <p><span class="privacy-dot" aria-hidden="true"></span> Vos données sont traitées de manière confidentielle. Votre mot de passe n’est jamais enregistré en clair.</p>
      <button class="button submit-button" type="submit">
        <span class="button-label">Créer mon compte</span>
        <span class="button-loading" aria-hidden="true">Envoi en cours…</span>
        <span class="button-arrow" aria-hidden="true">→</span>
      </button>
    </div>
    <p class="form-status" id="form-status" role="status" aria-live="polite"></p>
  </section>
</form>
