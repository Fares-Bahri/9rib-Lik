<?php

if (!defined('APP_ROOT')) {
    http_response_code(404);
    exit;
}

require APP_ROOT . '/views/layouts/header.php';
?>

    <section class="hero" aria-labelledby="hero-title">
      <div class="hero-content">
        <p class="eyebrow"><span aria-hidden="true"></span> Le goût du local, le sens du lien</p>
        <h1 id="hero-title">Chaque achat soutient<br>une ferme <em>près de chez vous.</em></h1>
        <p class="hero-description">Consommateurs ou producteurs, créez votre espace et rejoignez une communauté engagée pour une alimentation plus proche, plus juste et plus durable.</p>
        <ol class="progress" aria-label="Étapes de l’inscription">
          <li class="is-current" aria-current="step"><span>1</span> Votre profil</li>
          <li><span>2</span> Vos informations</li>
          <li><span>3</span> Bienvenue</li>
        </ol>
      </div>
      <aside class="hero-note" aria-label="Nos engagements">
        <span class="note-label">Une chaîne plus courte</span>
        <p>Des produits qui voyagent moins.<br>Des relations qui durent plus.</p>
        <div class="note-tags"><span>Local</span><span>Engagé</span><span>Humain</span></div>
      </aside>
    </section>

    <section class="registration-wrap" id="inscription" aria-labelledby="registration-title">
      <div class="registration-card">
        <div class="card-intro">
          <p class="card-kicker">Rejoignez l’aventure</p>
          <h2 id="registration-title">Créons votre compte</h2>
          <p id="role-help">Choisissez votre profil. Vous pourrez changer de choix avant de valider.</p>
        </div>

        <noscript>
          <p class="noscript-message">JavaScript doit être activé pour utiliser le formulaire interactif et la validation en temps réel.</p>
        </noscript>

        <?php require APP_ROOT . '/views/partials/registration-form.php'; ?>

        <section class="success-panel" id="success-panel" aria-labelledby="success-title" hidden>
          <div class="success-icon" aria-hidden="true">✓</div>
          <p class="card-kicker">Inscription confirmée</p>
          <h2 id="success-title" tabindex="-1">Bienvenue chez 9rib Lik !</h2>
          <p id="success-message">Votre compte a bien été créé. Merci de rejoindre notre communauté.</p>
          <p class="success-role" id="success-role"></p>
          <button class="button button-secondary" id="new-registration" type="button">Inscrire une autre personne</button>
        </section>
      </div>
    </section>

    <section class="values" id="avantages" aria-labelledby="values-title">
      <div class="values-intro">
        <p class="eyebrow"><span aria-hidden="true"></span> Plus qu’une plateforme</p>
        <h2 id="values-title">Un lien direct entre<br>la terre et votre assiette.</h2>
      </div>
      <div class="value-grid">
        <article><span class="value-number">01</span><h3>Des produits tracés</h3><p>Découvrez l’origine, les pratiques et les certifications de chaque ferme partenaire.</p></article>
        <article><span class="value-number">02</span><h3>Une économie locale</h3><p>Vos achats rémunèrent directement les producteurs et soutiennent les territoires.</p></article>
        <article><span class="value-number">03</span><h3>Des choix engagés</h3><p>Privilégiez la saison, la proximité et une manière de consommer plus responsable.</p></article>
      </div>
    </section>

<?php require APP_ROOT . '/views/layouts/footer.php'; ?>
